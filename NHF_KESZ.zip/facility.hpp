/**
*   @file facility.hpp
*   
*   @brief Declaration of the class Facility.
*/

#ifndef FACILITY_HPP
#define FACILITY_HPP

#include <fstream>
#include "teams.hpp"
#include "json.hpp"
#include "memtrace.h"

/**
 * @brief This is a heterogeneous collection.
 */
class Facility
{
private:
    std::vector<Team*> teams;
    size_t currentTeam;
public:
    /**
     * @param The team that the caller wants to add.
     *
     * @return true if the team is added.
     */
    bool addTeam(Team* team);
    /**
     * @param The team that the caller wants to remove.
     *
     * @return true if the team is removed.
     */
    bool removeTeam(Team team);
    /**
     * @param The index of the new current Team.
     *
     * @return true if the change happened.
     */
    bool setCurrentTeam(const size_t& n);
    /**
     * @return the index of the Current team.
     */
    size_t getCurrentTeam() const;
    /**
     * @return the size of the Facility.
     */
    size_t size() const;
    /**
     * @param index.
     *  
     * @return the the team with this index.
     */
    Team* operator[](size_t idx);
    /**
     * @brief Custom operator that returns the type of the team too.
     * 
     * @param idx the index of the team that the caller wants.
     * 
     * @return A team pointer with the current team type.
     */
    template<typename C>
    C* getTeam(size_t idx)
    {
        size_t n = 0;
        for (size_t i = 0; i < teams.size(); i++)
        {
            C* t;
            if ((t = dynamic_cast<C*>(teams[i])))
            {
                n++;
            }
            if (idx == n)
            {
                return t;
            }
        }
        return nullptr;
    }   

    /**
     * @brief Lists the Football teams to the ostream.
     */
    std::ostream& listFootballTeams(std::ostream& os);
    /**
     * @brief Lists the Basketball teams to the ostream.
     */
    std::ostream& listBasketballTeams(std::ostream& os);
    /**
     * @brief Lists the Handball teams to the ostream.
     */
    std::ostream& listHandballTeams(std::ostream& os);
    /**
     * @brief Destructor.
     */
    
    ~Facility() 
    {
        for (size_t i = 0; i < teams.size(); i++)
        {
            delete teams[i];
        }
    }
};

#endif