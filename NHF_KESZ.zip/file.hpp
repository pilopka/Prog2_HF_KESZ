/**
*   @file file.hpp
*   
*   @brief Declaration of the class FileHandler.
*/

#ifndef FILE_HPP
#define FILE_HPP

#include "facility.hpp"
#include "json.hpp"
#include "memtrace.h"

class FileHandler
{
private:
    std::string fPath;
    std::string bPath;
    std::string hPath;

public:
    /**
     * @brief Construct a new File Handler object.
     * 
     * @param fileF The name and location of the file that contains the Football teams.
     * @param fileB The name and location of the file that contains the Basketball teams.
     * @param fileH The name and location of the file that contains the Handball teams.
     */
    FileHandler(std::string fileF, std::string fileB, std::string fileH): fPath(fileF), bPath(fileB) , hPath(fileH) {}

    /**
     * @brief Reads all the Football teams from fileF.
     * 
     * @return A vector that contains all the Football teams. 
     */
    std::vector<FootballTeam*> readFootballTeams();
    /**
     * @brief Reads all the Basketball teams from fileB.
     * 
     * @return A vector that contains all the Basketball teams. 
     */
    std::vector<BasketballTeam*> readBasketballTeams();
    /**
     * @brief Reads all the Handball teams from fileH.
     * 
     * @return A vector that contains all the Handball teams. 
     */
    std::vector<HandballTeam*> readHandballTeams();

    /**
     * @brief At the end of the program writes the changed Football teams back to FileF.
     * 
     * @param ft the separated Football teams.
     */
    void writeFootballTeam(std::vector<FootballTeam> ft);
    /**
     * @brief At the end of the program writes the changed Basketball teams back to FileB.
     * 
     * @param ft the separated Basketball teams.
     */
    void writeBasketballTeam(std::vector<BasketballTeam> ft);
    /**
     * @brief At the end of the program writes the changed Handball teams back to FileH.
     * 
     * @param ft the separated Handball teams.
     */
    void writeHandballTeam(std::vector<HandballTeam> ft);

    /**
     * @brief Reads all the teams into the facility.
     * 
     * @return The facility that was created from all the different files.
     */
    Facility readFacility();
    /**
     * @brief Separates all the teams and writes them back to the files one by one.
     * 
     * @param changedFacility the changed facility at the and of the program.
     */
    void writeFacility(Facility changedFacility);
};


#endif