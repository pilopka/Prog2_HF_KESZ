/**
*   @file teams.hpp
*   
*   @brief Declaration of the classes Team and the three different teams.
*/

#ifndef TEAMS_HPP
#define TEAMS_HPP

#include "person.hpp"
#include "memtrace.h"

class Team
{
private:
    std::string name;
    std::vector<Person> players;
public:
    /**
     * @brief Construct a new Team object.
     * 
     * @param name The name of the Team.
     */
    Team(std::string name): name(name) {}

    /**
     * @brief Adds a new player to the team.
     * 
     * @param player 
     * @return true If the player is added.
     * @return false If the player is already a team member.
     */
    bool addPlayer(const Person& player);
    /**
     * @brief Removes a player from the team.
     * 
     * @param player 
     * @return true If the player is removed.
     * @return false If the player is not a team member.
     */
    bool removePlayer(const Person& player);
    /**
     * @brief 
     * 
     * @param team the Team that the caller wants to compair the object with. 
     * @return true The two Teams are the same.
     * @return false The two Teams are different.
     */
    bool operator==(const Team& team);
    /**
     * @brief Get the Player object with the given index.
     * 
     * @param idx the index of the needed player.
     * @return Person& A refenrece to the player with the given index.
     */
    Person& getPlayer(size_t idx);
    /**
     * @brief Get the Name.
     * 
     * @return The name of the team.
     */
    std::string getName() const;
    /**
     * @brief Get the Size. 
     * 
     * @return The size of the team.
     */
    size_t size() const;

    /**
     * @brief Writes the team to the ostream.
     */
    virtual std::ostream& print(std::ostream& os);

    /**
     * @brief Destroy the Team object.
     * 
     */
    virtual ~Team() {}
};

class FootballTeam : public Team
{
private:
    std::vector<Person> coaches;
public:
    /**
     * @brief Construct a new Football Team object.
     * 
     * @param name The team's name.
     */
    FootballTeam(std::string name): Team(name) {}

    /**
     * @brief Adds a Coach to the team.
     * 
     * @param coach 
     * @return true If the Coach is added.
     * @return false If the Coach is already in the team.
     */
    bool addCoach(const Person& coach);
    /**
     * @brief Removes a Coach from the team.
     * 
     * @param coach 
     * @return true If the Coach is removed.
     * @return false If the Coach is not in the team.
     */
    bool removeCoach(const Person& coach);
    /**
     * @brief Get the Coach with the given index.
     * 
     * @param idx the index of the needed coach.
     * @return Person& A refenrece to the coach with the given index.
     */
    Person& getCoach(size_t idx);
    /**
     * @brief Get the Number of the coaches. (0, 1 or 2)
     * 
     * @return The number.
     */
    size_t numberOfCoaches() const;

    /**
     * @brief Writes the Football team to the ostream.
     */
    std::ostream& print(std::ostream& os);

    /**
     * @brief Destroy the Football Team object.
     * 
     */
    ~FootballTeam() {}
};

class BasketballTeam : public Team
{
private:
    std::vector<Person> cheerleaders;
public:
    /**
     * @brief Construct a new Basketball Team object.
     * 
     * @param name The team's name.
     */
    BasketballTeam(std::string name): Team(name) {}

    /**
     * @brief Adds a Cheerleader to the team.
     * 
     * @param cheerleader 
     * @return true If the Cheerleader is added.
     * @return false If the Cheerleader is already in the team.
     */
    bool addCheerleader(const Person& cheerleader);
    /**
     * @brief Removes a Cheerleader from the team.
     * 
     * @param cheerleader 
     * @return true If the Cheerleader is removed.
     * @return false If the Cheerleader is not in the team.
     */
    bool removeCheerleader(const Person& cheerleader);
    /**
     * @brief Get the Cheerleader with the given index.
     * 
     * @param idx the index of the needed cheerleader.
     * @return Person& A refenrece to the cheerleader with the given index.
     */
    Person& getCheerleader(size_t idx);
    /**
     * @brief Get the Number of the Cheerleaders.
     * 
     * @return The number.
     */
    size_t numberOfCheerleaders();

    /**
     * @brief Writes the Basketball team to the ostream.
     */
    std::ostream& print(std::ostream& os);

    /**
     * @brief Destroy the Basketball Team object.
     * 
     */
    ~BasketballTeam() {}
};

class HandballTeam : public Team
{
private:
    size_t supportMoney;
public:
    /**
     * @brief Construct a new Handball Team object.
     * 
     * @param name The name of the team.
     * @param value The value of the Yearly Support money. 
     */
    HandballTeam(std::string name, size_t value = 0): Team(name), supportMoney(value) {}

    /**
     * @brief Changes the value of the Yearly Support money to a new given value.
     * 
     * @param newValue The new value of the money.
     */
    void changeSupportMoney(size_t newValue);
    /**
     * @brief Get the Value.
     * 
     * @return The money.
     */
    size_t getValue() const;

    /**
     * @brief Writes the Handball team to the ostream.
     */
    std::ostream& print(std::ostream& os);

    /**
     * @brief Destroy the Handball Team object.
     * 
     */
    ~HandballTeam() {}
};

#endif