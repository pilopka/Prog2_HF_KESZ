/**
*   @file person.hpp
*   
*   @brief Declaration of the class Person.
*/

#ifndef PERSON_HPP
#define PERSON_HPP

#include <iostream>
#include <vector>
#include "memtrace.h"

class Person
{
private:
    std::string name;
    size_t age;
public:
    /**
     * @brief Construct a new Person object.
     * 
     * @param name The name of the Person.
     * @param age The age of the Person.
     */
    Person(std::string name, size_t age): name(name), age(age) {}

    /**
     * @brief Get the Name.
     * 
     * @return The name of the Person.
     */
    std::string getName() const;
    /**
     * @brief Get the Age.
     * 
     * @return The age of the Person.
     */
    size_t getAge() const;
    
    /**
     * @brief 
     * 
     * @param person the Pesron that the caller wants to compair the object with. 
     * @return true The two People are the same.
     * @return false The two People are different. 
     */
    bool operator==(const Person& person) const;
    /**
     * @brief 
     * 
     * @param person the Pesron that the caller wants to compair the object with. 
     * @return true The two People are different.
     * @return false The two People are the same.
     */
    bool operator!=(const Person& person) const;
};

#endif