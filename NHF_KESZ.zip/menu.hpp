/**
*   @file menu.hpp
*   
*   @brief Declaration of the classes Menu and Menuhandler.
*/

#ifndef MENU_HPP
#define MENU_HPP

#include "facility.hpp"
#include "memtrace.h"

enum State
{
    Football,
    Basketball,
    Handball,
    Quit
};

class Menu
{
private:
    std::vector<std::string> buttons;
    static State state;
public:
    /**
     * @brief Construct a new Menu object.
     * 
     * @param buttons A vector that contaions all the Buttons in order.
     */
    Menu(std::vector<std::string> buttons): buttons(buttons) {}

    /**
     * @brief Set the State.
     * 
     * @param n The next state.
     */
    void setState(const State& n);
    /**
     * @brief Get the State.
     * 
     * @return State 
     */
    State getState() const;

    /**
     * @brief Writes the Menu to the ostream.
     */
    std::ostream& print(std::ostream& os);
    /**
     * @brief Gets a number from the istream and checks if that number can push a button or not.
     * 
     * @return size_t the number of the Selected button.
     */
    size_t select(std::istream& is);
};

/**
 * @brief This is a heterogeneous collection.
 */
class MenuHandler
{
private:
    std::vector<Menu> menus;
    size_t currentMenuIndex;
public:
    /**
     * @brief Construct a new Menu Handler object.
     * 
     * @param menus A vector that contains all the menus.
     */
    MenuHandler(std::vector<Menu> menus): menus(menus), currentMenuIndex(0) {}

    /**
     * @brief Adds a new menu to the vector.
     * 
     * @param newMenu
     */
    void addMenu(Menu newMenu);
    /**
     * @brief Deletes the old menu and replaces it with the new one.
     * 
     * @param oldMenu 
     * @param newMenu 
     */
    void changeMenu(Menu oldMenu, Menu newMenu);
    /**
     * @brief Moves the menu forwards.
     */
    void toPrevMenu();
    /**
     * @brief Moves the menu backwards.
     */
    void toNextMenu();
    /**
     * @brief Get the Index.
     * 
     * @return size_t The index of the current menu.
     */
    size_t getIndex() const;
    /**
     * @brief Set the State.
     * 
     * @param n The state of the new menu.
     */
    void setState(const State& n);
    /**
     * @brief Get the State.
     * 
     * @return The current State of the menu.
     */
    State getState() const;

    /**
     * @param i index.
     * @return Menu& A reference to the current menu.
     */
    Menu& operator[](size_t i);

    /**
     * @brief Writes the menu to the ostream.
     */
    std::ostream& print(std::ostream& os);
    /**
     * @brief Gets a number from the istream and checks if that number can push a button or not.
     * 
     * @return size_t the number of the Selected button.
     */
    size_t select(std::istream& is);
};

#endif
